<center><h1>SnapSketch 🤞</h1></center>
<center><h2>Version - 1.0.0</h2></center>
<h3>
Ever Hustled with writing very long and huge lines of codes that takes long time, then buckle up here is a solution for all your hustle introducing ' SnapSketch '. A python graphical library which is made using python turtle base. This Package contains a total list of 39+ graphics which made simple by just simply importing the library and by defining a single line of function.</h3>

## To use - 
```python
import SnapSketch #or
# import SnapSketch as ss
```
## Now lets summarize some of the utilities and functions of the SnapSketch - 
<h3>
Graph() - Draw a simple basic Graph

Panda() - Draw a Panda Sketch

SortAlgorithm() - This a interface that contains insertion sort, selection sort and many more and select the required sorting algorithm and sort the specified poles

Star() - Draw a Star

Cube() - Draw a basic Cube

GoogleLogo() - Draw Google Logo

WindowsLogo() - Draw Windows Logo

IronMan() - Draw IronMan character

Car() - Draw Car sketch

Infinity() - Draw an Infinity loop/symbol

IndiaFlag() - Draw the Indian Flag

AmongUs() - Draw AmongUs character 

Heart() - Draw a Heart Shape

TurtleRace() - Participate and select a specific colored turtle and try to win the race

YinYang() - Draw a YinYang shape 

Peace() - Draw Peace Shape with all colors
</h3>